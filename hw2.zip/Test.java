public class Test {
   int method_1() {
      int num1=12;
      int num2=1;
      while (num1>0){
         num2*=num1;
         num1--;
      }
   return num2;   
   }
   int method_2() {
      int num3=1;
      int sum=0;
      while (num3<=255){
         sum+=num3*num3;
         num3++;
      }
   return sum;
   }
   int method_3() {
      int cnt=0;
      for (int num4=1; num4<=(997/2);num4++){
         if(977%num4==0) cnt++;
      }
      if (cnt==0) return 1;
      return 0;
   }
   public static void main(String[] args) {
      Test obj = new Test();
      System.out.println("method_1 = " + obj.method_1());
      System.out.println("method_2 = " + obj.method_2());
      if (obj.method_3()==0) System.out.println("997�� �Ҽ��Դϴ�");
      else System.out.println("997�� �Ҽ��� �ƴմϴ�");
   }
}
    
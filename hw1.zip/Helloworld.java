class Helloworld {
public static void main(String [] args) 
{
System.out.println("2016320131 ���°�");
}
}
